package lab2.Dao;

import lab2.Models.Trainee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TraineeDao extends JpaRepository<Trainee,Integer> {

}
