package lab2.Services;

public class TraineeService {
}
