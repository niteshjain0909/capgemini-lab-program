package lab2.Models;

import javax.persistence.*;

@Entity
@Table(name = "Trainee")
public class Trainee {
    @Id
    @Column(name ="traineeId")
    @GeneratedValue(strategy = GenerationType.AUTO)
    int traineeId;
    @Column(name ="traineeName")
    String traineeName;
    @Column(name ="traineeDomain")
    String traineeDomain;
    @Column(name ="traineeLocation")
    String traineeLocation;

    public Trainee(){

    }


    public Trainee(String traineeName, String traineeDomain, String traineeLocation) {
        this.traineeName = traineeName;
        this.traineeDomain = traineeDomain;
        this.traineeLocation = traineeLocation;
    }

    public int getTraineeId() {
        return traineeId;
    }

    public void setTraineeId(int traineeId) {
        this.traineeId = traineeId;
    }

    public String getTraineeName() {
        return traineeName;
    }

    public void setTraineeName(String traineeName) {
        this.traineeName = traineeName;
    }

    public String getTraineeDomain() {
        return traineeDomain;
    }

    public void setTraineeDomain(String traineeDomain) {
        this.traineeDomain = traineeDomain;
    }

    public String getTraineeLocation() {
        return traineeLocation;
    }

    public void setTraineeLocation(String traineeLocation) {
        this.traineeLocation = traineeLocation;
    }


}
