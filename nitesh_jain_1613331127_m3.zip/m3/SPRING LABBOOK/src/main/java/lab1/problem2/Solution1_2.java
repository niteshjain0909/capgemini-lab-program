package lab1.problem2;

import lab1.problem2.Model.Employee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Solution1_2 {
    public static void main(String[] args) {
        ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
        Employee e1=(Employee) context.getBean("employee2");
        System.out.println(e1.toString());
    }
}
