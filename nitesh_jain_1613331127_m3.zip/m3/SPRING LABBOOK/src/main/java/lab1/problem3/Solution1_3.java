package lab1.problem3;

import lab1.problem3.Model.Employee;
import lab1.problem3.Model.SBU;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Solution1_3 {
    public static void main(String[] args) {
        ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
        SBU e1=(SBU) context.getBean("sbu3");
        System.out.println(e1.toString());
    }
}
