package lab1.problem1;

import lab1.problem1.Model.Employee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Solution1_1 {
    public static void main(String[] args) {
        ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
        Employee e1=(Employee) context.getBean("employee");
        System.out.println(e1.toString());


    }
}
