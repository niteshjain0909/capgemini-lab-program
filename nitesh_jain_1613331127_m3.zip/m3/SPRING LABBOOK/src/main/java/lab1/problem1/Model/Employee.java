package lab1.problem1.Model;

public class Employee {

    int employeeId;
    String employeeName;
    String businessUnit;

    int age;

    public Employee() {

    }


    public Employee(int employeeId, String employeeName, String businessUnit, int age, double salary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.businessUnit = businessUnit;
        this.age = age;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", employeeName='" + employeeName + '\'' +
                ", businessUnit='" + businessUnit + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                '}';
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    double salary;


}
