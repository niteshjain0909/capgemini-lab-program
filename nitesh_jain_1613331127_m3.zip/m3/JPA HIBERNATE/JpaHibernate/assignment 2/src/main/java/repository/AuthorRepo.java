package repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import model.Author;

public class AuthorRepo {
	
	private EntityManager entityManager;
    public AuthorRepo(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    
    public List<Author> findAll() {
        return entityManager.createQuery("from Author").getResultList();
    }
    
    public Optional<Author> findById(Integer id) {
        Author author = entityManager.find(Author.class, id);
        return author != null ? Optional.of(author) : Optional.empty();
    }
    
    public Optional<Author> findByName(String name) {
        Author author = entityManager.createNamedQuery("Author.findByName", Author.class)
                .setParameter("name", name)
                .getSingleResult();
        return author != null ? Optional.of(author) : Optional.empty();
    }
    
    
	/*
	 * public List<Author> findByBookId(int id) { List<Author> author
	 * =entityManager.
	 * createQuery("SELECT a from Author a JOIN Book b where b.id=:id",Author.class)
	 * .setParameter("id", id).getResultList(); return author;
	 * 
	 * 
	 * }
	 */
    
    public Optional<Author> save(Author author) {
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(author);
            entityManager.getTransaction().commit();
            return Optional.of(author);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

}
