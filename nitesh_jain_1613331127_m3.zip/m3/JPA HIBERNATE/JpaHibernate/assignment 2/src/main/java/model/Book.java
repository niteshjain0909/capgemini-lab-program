package model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
@Entity
@Table(name="book")
@NamedQueries({
    @NamedQuery(name = "Book.findByPrice",
            query = "SELECT b FROM Book b WHERE b.price >= 500 AND b.price <=1000"),
    @NamedQuery(name = "Book.findAll",
            query = "SELECT b FROM Book b")
   
})
public class Book {
	@Id
	private int isbn;
	private String title;
	private int price;
	 @ManyToOne
	 @JoinColumn(name="id")
	 private Author author;
	 
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Book(int isbn, String title, int price) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.price = price;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price + ", author=" + author.getName() + "]";
	}
	

}
