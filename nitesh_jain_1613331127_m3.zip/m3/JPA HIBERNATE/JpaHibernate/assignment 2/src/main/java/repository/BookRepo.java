package repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import model.Book;

public class BookRepo {
	
	 private EntityManager entityManager;
	    public BookRepo(EntityManager entityManager) {
	        this.entityManager = entityManager;
	    }

	    public List<Book> findAll() {
	        return entityManager.createQuery("from Book").getResultList();
	    }
	    
	    public Optional<Book> findByName(String name) {
	        Book book = entityManager.createQuery("SELECT b FROM Book b WHERE b.name = :name", Book.class)
	                .setParameter("name", name)
	                .getSingleResult();
	        return book != null ? Optional.of(book) : Optional.empty();
	    }
	    
	    
	    public List<Book> findByPrice()
	    {
	    	 List<Book> book =entityManager.createQuery("SELECT b FROM Book b WHERE b.price >= 500 AND b.price <=1000 ",Book.class)
	    			.getResultList();
		
	    		return book;	
	    }
	    
	    
	    public List<Book> findByAuthorName(String name){
	    	 List<Book> book = entityManager.createQuery("SELECT b from Book b JOIN Author a ON  a.name =:name", Book.class)
		                .setParameter("name", name)
		                .getResultList();
		        return book ;
	    	
	    }
	    
	    
	    public Optional<Book> save(Book book) {
	        try {
	            entityManager.getTransaction().begin();
	            entityManager.persist(book);
	            entityManager.getTransaction().commit();
	            return Optional.of(book);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return Optional.empty();
	    }
}
