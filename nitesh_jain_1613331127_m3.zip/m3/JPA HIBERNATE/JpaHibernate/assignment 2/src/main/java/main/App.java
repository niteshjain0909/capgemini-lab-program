package main;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.Author;
import model.Book;
import repository.AuthorRepo;
import repository.BookRepo;

public class App {
	
	 public static void main(String[] args) {
	        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
	        EntityManager entityManager = entityManagerFactory.createEntityManager();

	        BookRepo bookRepository = new BookRepo(entityManager);
	        AuthorRepo authorRepository = new AuthorRepo(entityManager);
	      

	        
	        Author author = new Author("Author 1");
	        author.addBook(new Book(1,"Book 1",800));
	        author.addBook(new Book(2,"Book 2",1000));
	        author.addBook(new Book(3,"Book 3",200));
	        
	        Optional<Author> savedAuthor = authorRepository.save(author);
	        System.out.println("Saved author: " + savedAuthor.get());
	        
	        
	        List<Book> books = bookRepository.findAll();
	        System.out.println("Books:");
	        books.forEach(System.out::println);
	        
	        Optional<Author> authorByName = authorRepository.findByName("Author 1");
	        System.out.println("Searching for an author by name: ");
	        authorByName.ifPresent(System.out::println);
	        
	        List<Book> book = bookRepository.findAll();
	        System.out.println("Books in database:");
	        books.forEach(System.out::println);
	        
	        List<Book> bookobj = bookRepository.findByPrice();
	        System.out.println("Books in range 500-1000:");
	        bookobj.forEach(System.out::println);
	        
	        List<Book> booksobj = bookRepository.findByAuthorName("Author 1");
	        System.out.println("Books by given author:");
	        booksobj.forEach(System.out::println);
	        
	       
	        entityManager.close();
	        entityManagerFactory.close();
	      

	    }

}
