package main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.Author;

public class App {
	 public static void main(String[] args) {
	        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
	        EntityManager entityManager = entityManagerFactory.createEntityManager();

	        System.out.println("Starting Transaction");
	        entityManager.getTransaction().begin();
	        Author author = new Author();
	        author.setFirstname("Bob");
	        author.setLastname("Stephon");
	        System.out.println("Saving Author to Database");

	        entityManager.persist(author);
	        entityManager.getTransaction().commit();
	        System.out.println("Generated Employee ID = " + author.getId());

	        // get an object using primary key.
	        Author author1 = entityManager.find(Author.class, author.getId());
	        System.out.println("got object " + author1.getFirstname() + " " + author1.getId()+" "+author1.getLastname());

	        // get all the objects from author table
	        @SuppressWarnings("unchecked")
	        List<Author> listAuthor = entityManager.createQuery("SELECT e FROM Author e").getResultList();
	        if (listAuthor == null) {
	            System.out.println("No author found.");
	        } else {
	            for (Author auth : listAuthor) {
	                System.out.println("author name= " + auth.getFirstname() + " " + auth.getId()+" "+auth.getLastname());
	               
	            }
	        }
	        // remove 
	        entityManager.getTransaction().begin();
	        System.out.println("Deleting author with ID = " + author1.getId());
	        entityManager.remove(author1);
	        entityManager.getTransaction().commit();

	        // close the entity manager
	        entityManager.close();
	        entityManagerFactory.close();

	    }

}
